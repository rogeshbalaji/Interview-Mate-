AI-Based Internship Review Automation System - HTML Website
===========================================================
HOW TO OPEN
  Unzip, then double-click index.html (works offline except Excel import/export,
  which loads a small library from the internet).

PAGES
  index.html      Project website (workflow, objectives, features, technologies)
  dashboard.html  Coordinator dashboard (import Excel, reminders, AI review, history)
  submit.html     Page students open from their email to submit GitHub + recording links

COORDINATOR WORKFLOW
  1. Dashboard > Settings: enter your email (and optionally a Claude API key). Save.
  2. Import Excel (columns: Name, Email, Review Date, Review Time) or add students manually.
  3. Click "Reminder" on a student: an email with their submission link opens. Send it.
  4. The student submits; their message arrives by email. Click "Add submission" and paste the links.
  5. Click "AI review": feedback is generated and an email opens with the next review date.
  6. Repeats until the total number of reviews is reached, then the student is Completed.

HOSTING (so students can open the submission link)
  Upload the folder to GitHub Pages or Netlify (both free). Opening from your own
  computer works for you, but students need a public web address.

NOTES
  - Data is saved in your browser (localStorage). Use "Export Excel" for backups.
  - AI review reads public GitHub repositories. Without a Claude key it uses built-in checks.
  - A Claude key typed into the dashboard stays in your browser; do not host a page with a key inside it.
  - Emails open in your mail app; this static site cannot send emails by itself.
